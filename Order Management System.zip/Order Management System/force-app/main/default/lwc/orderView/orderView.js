import { LightningElement,api,track } from 'lwc';
import getOrder from '@salesforce/apex/ViewOrderController.getOrder';
import { NavigationMixin } from 'lightning/navigation';
export default class OrderView extends NavigationMixin(LightningElement) {
    @api recordId;
    order;productDetails;
    priceBookId;aa=false;
    productList=[];
    
    connectedCallback(){
        getOrder({orderId:this.recordId})
        .then(result=>{
            this.order=result[0];  
            console.log(this.recordId);           
                 
        });
    }
    showProductDetails()
    { 
        
             
        this[NavigationMixin.Navigate]({
            type: 'standard__recordRelationshipPage',
            attributes: {
                recordId: this.recordId,
                objectApiName: 'Order',
                relationshipApiName: 'OrderItems',
                actionName: 'view'
            }
        });
}
showApprovalDetails()
{
    this[NavigationMixin.Navigate]({
        type: 'standard__recordRelationshipPage',
        attributes: {
            recordId: this.recordId,
            objectApiName: 'Order',
            relationshipApiName: 'ProcessSteps',
            actionName: 'view'
        }
    });
}
showInvoice()
{
    this[NavigationMixin.Navigate]({
        type: 'standard__recordRelationshipPage',
        attributes: {
            recordId: this.recordId,
            objectApiName: 'Order',
            relationshipApiName: 'Invoice__r',
            actionName: 'view'
        }
    });
}
}