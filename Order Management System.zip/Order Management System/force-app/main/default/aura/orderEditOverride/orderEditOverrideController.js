({
    handleSuccess : function(component, event, helper) {
    var payload = event.getParams().response;
    var navService = component.find("navService");
        console.log('qq');
    var pageReference = {
        type: 'standard__recordPage',
        attributes: {
            "recordId": payload.id,
            "objectApiName": "Order",
            "actionName": "view"
        }
    }
    console.log("hii");
    event.preventDefault();
    navService.navigate(pageReference);  
    }    
})