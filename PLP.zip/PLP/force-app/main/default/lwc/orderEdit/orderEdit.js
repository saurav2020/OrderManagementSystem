import { LightningElement,api } from 'lwc';
import {
    ShowToastEvent
    } from 'lightning/platformShowToastEvent';
    //import { NavigationMixin } from 'lightning/navigation';
    //import { ShowToastEvent } from 'lightning/platformShowToastEvent';
    import getOrder from'@salesforce/apex/ViewOrderController.getOrder';
export default class OrderEdit extends LightningElement{
    @api recordId;
      order;
    connectedCallback(){
        getOrder({orderId:this.recordId})
        .then(result=>{
            this.order=result[0];  
            console.log(this.recordId);
            console.log(this.order);           
                 
        });
    }

    
    /*handleSubmit(event) {
        console.log(recordId);
        console.log('onsubmit: '+ event.detail.fields);
 
    }
    handleSuccess(event) {
        const updatedRecord = event.detail.id;
        console.log('onsuccess: ', updatedRecord);
        console.log(recordId);
    }*/
   
 
}