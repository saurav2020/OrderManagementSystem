import { LightningElement, wire, track} from 'lwc';
import getProducts from '@salesforce/apex/OrderController.getProducts';
import getProductsBrand from '@salesforce/apex/OrderController.getProductsBrand';
import getProductsPrice from '@salesforce/apex/OrderController.getProductsPrice';
import orderCreation from '@salesforce/apex/OrderController.orderCreation';
import getValue from '@salesforce/apex/OrderController.getValue';
//import { NavigationMixin } from 'lightning/navigation';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';    

export default class Sample_Create extends LightningElement {
    productList;
    FinalPrice=0;
    FinalPriceINR=0;
    searchVal;showSearchList=false;
    selectedProductList=[];
    selectedProductList1=[];
    selectedTableToggle=true;
    showFinalTable=false;
    orderProducts=false;
    stock=0;
    errorsaving=false;
    showsearchbar=true;
    orderValue=0;
    showUpdate=false;
    showOrderSummary=false;
    search(event)
    {
        var inp=this.template.querySelectorAll("lightning-input");
        inp.forEach(function(element)
        {console.log('Entered input log');
            if(element.name == "productName")
            {console.log(element.value);
                if(element.value.length !=0)
                {
                getProducts({searchVal:element.value,priceBookId:'01s2x000001KHSRAA4'})
            .then(result=>{
                this.productList=JSON.parse(result);
                
               
            });
            this.showSearchList=true;
            //this.showsearchbar=false;
            }}
            if(element.name == "productBrand")
            {
                console.log(element.value);
                if(element.value.length !=0)
                {
                getProductsBrand({searchVal:element.value,priceBookId:'01s2x000001KHSRAA4'})
            .then(result=>{
                this.productList=JSON.parse(result);
               
            });
            console.log(this.productList);
            console.log(typeof this.productList);
            this.showSearchList=true;
            
            }}
            if(element.name == "productPrice")
            {
                console.log(element.value);
                if(element.value.length !=0)
                {
                getProductsPrice({searchVal:element.value,priceBookId:'01s2x000001KHSRAA4'})
            .then(result=>{
                this.productList=JSON.parse(result);
               
            });
            this.showSearchList=true;
            console.log(this.productList);
            
           
            }}
        },this);
        var inp1=this.template.querySelectorAll("lightning-input-field");
        inp1.forEach(function(element)
        { console.log('Acc');
            if(element.name="accName")
            {
        console.log(element.value);
        this.accountId=element.value;
            }
        },this);
        //this.showsearchbar=false;
    }


    addProduct(event){
        this.selectedTableToggle=false;
        var id=event.target.value;
        var index = -1;
        var selectedproduct=new Object();
        for(var product of this.productList){
            index++;
            if(id==product.Id){
                selectedproduct.Id=product.Id;
                selectedproduct.Name=product.Name;
                selectedproduct.ProductCode=product.ProductCode;
               selectedproduct.Brand=product.Brand__c;
                selectedproduct.Stock_Quantity=product.Stock_Quantity__c;
                selectedproduct.Quantity='1';
                selectedproduct.UnitPrice=0;
                selectedproduct.ListPrice=product.ListPrice;
                selectedproduct.Discount=product.Discount__c;
                selectedproduct.PriceBookEntryId=product.PriceBookEntryId;
                
               
                break;
            }
        }
        if(!this.selectedProductList.some(item => item.Id === selectedproduct.Id)){
            this.selectedProductList.push(selectedproduct);
            // Stock of selected Product
            this.stock=selectedproduct.Stock_Quantity;
            console.log(this.stock);
        }
       this.showSearchList=false;
      // this.showSearchList=true;
        this.selectedTableToggle=true;
        //this.selectedProductList.splice(0,1);
    }

    updateQuantity(event){
        var index = -1;
        for(var product of this.selectedProductList){
            index++;
            if(event.target.name==product.Id){
                break;
            }
        }
        this.selectedProductList[index].Quantity=event.target.value;
        //this.quantity=this.selectedProductList[index].Quantity;
        //console.log(this.quantity);
    }
    removeClicked(event){
        var id=event.target.value;
        for(var product of this.selectedProductList){
            if(id==product.Id){
                const index = this.selectedProductList.indexOf(product);
                this.selectedProductList.splice(index,1)
            }
        }
        this.selectedTableToggle=false;
        this.selectedTableToggle=true;
        this.showsearchbar=true;
    }
    
    
saveClicked()
{
    this.selectedTableToggle=false;
    var size= this.selectedProductList.length;  
      console.log(this.selectedProductList[size-1].Stock_Quantity);
             for(var product of this.selectedProductList)
             {
                 console.log(product.Quantity);
                // product.UnitPrice=product.ListPrice - (product.ListPrice * product.Discount / 100); 
                 if(product.Quantity>10)
                 product.Quantity=parseInt(product.Quantity)+1;
             }
             this.showFinalTable=true;
             this.showUpdate=true;
             
             //this.showOrderSummary=true;
             //this.orderSummary();
             this.showsearchbar=true;
}
cancel()
{
    window.location.reload();
}
editOrder()
{
    this.showSearchList=true;
}
saveOrder()
{
    for(var product of this.selectedProductList)
    {           
        product.UnitPrice=product.ListPrice - (product.ListPrice * product.Discount / 100);            
    }
    orderCreation({selectedProducts:JSON.stringify(this.selectedProductList),priceBookId:'01s2x000001KHSRAA4',accId:this.accountId})
    .then(result=>{
        this.msg=result;
        console.log('Order Id : ' + this.msg);
        if(this.msg == 'Error')
    {      console.log(this.msg);
        alert('Entire Order Not Saved');
        const evt = new ShowToastEvent({
            title: 'Order Insertion',
            message: 'Entire Order Not Saved ',
            variant: 'error',
            mode: 'dismissable'
        });
        this.dispatchEvent(evt);
        this.cancel();
        this.errorsaving=true;
        }
        else
        {
            alert('Entire Order Saved');
            const evt = new ShowToastEvent({
                title: 'Order Insertion',
                message: 'Entire Order  Saved ',
                variant: 'success',
                mode: 'dismissable'
            });
            this.dispatchEvent(evt);
            this.cancel();
        }
        
    })    
}
orderSummary()
{
    
    for(var product of this.selectedProductList)
    {   
        var selectedproduct=new Object();
             selectedproduct.Id=product.Id;
            selectedproduct.Name=product.Name;
            selectedproduct.ProductCode=product.ProductCode;
           selectedproduct.Brand=product.Brand;
            selectedproduct.Stock_Quantity=product.Stock_Quantity;
            selectedproduct.Quantity=product.Quantity;
            selectedproduct.UnitPrice=product.ListPrice - (product.ListPrice * product.Discount / 100);           
            selectedproduct.Discount=product.Discount;            
            if(selectedproduct.Quantity>11)
            selectedproduct.Price=(selectedproduct.Quantity-1)*selectedproduct.UnitPrice;
            else
            selectedproduct.Price=selectedproduct.Quantity*selectedproduct.UnitPrice;
            this.selectedProductList1.push(selectedproduct);
            console.log(this.selectedProductList1[0]);           
    }
    for(var product of this.selectedProductList1)
    this.FinalPrice= this.FinalPrice+product.Price;
    getValue({amt:this.FinalPrice})
            .then(result=>{
                this.FinalPriceINR=result;               
            });
    this.showOrderSummary=true;
}
}